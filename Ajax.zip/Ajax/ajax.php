<html>

<body>

<?php
$query=mysql_connect("localhost","root","");
mysql_select_db("ajax",$query);
$name=$_POST['name'];
$email=$_POST['email'];

$sql = mysql_query("insert into employee (name,email) values ('$name','$email')");
?>
</body>
</html>