<html>
<head>
<link href="bootstrap/bootstrap.min.css" rel="stylesheet"/>
</head>
<body>
<?php
$query=mysql_connect("localhost","root","");
mysql_select_db("ajax",$query);

$result = "";
$sql1 = mysql_query("SELECT * from employee");

while($row = mysql_fetch_array($sql1))
{
	$id = $row['ID'];
	$name1 = $row['name'];
	$email1 = $row['email'];
	
	$result .= "<tr>
					<td>$name1</td>
					<td>$email1</td>
					<td><a href=''?id='".$id."' class='delete'>Delete</a></td>
				</tr>";  
}
?>
<table border="1" class="table table-responsive">
	<tr class="bg-primary">
    	<th>Name</th>
        <th>Email</th>
        <th>Delete</th>
    </tr>
    <?php echo $result; ?>
</table>
</body>
</html>