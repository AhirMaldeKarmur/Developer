<?php
$con = mysql_connect("localhost","root","");
$query = mysql_select_db("ajax",$con);

$music_number = "POST['id']";
$qry = "DELETE FROM employee WHERE id ='$music_number'";
$result=mysql_query($qry);

?>