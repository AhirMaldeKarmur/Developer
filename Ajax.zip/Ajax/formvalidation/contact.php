
<script>
	alert("success");
	window.location = "index.php";
</script>

