<html>
<head>
	<title>Ajax Form Validation</title>
</head>
<link href="../bootstrap/bootstrap.min.css" rel="stylesheet"/>
<script src="../jquery-1.6.2.min.js" type="text/javascript"></script>
<script>

function sendContact() 
{
	var valid;	
	valid = validateContact();
	if(valid) 
	{
		jQuery.ajax({
		url: "contact.php",
		data:'userName='+$("#userName").val()+'&userEmail='+$("#userEmail").val()+'&subject='+$("#subject").val()+'&content='+$("#content").val(),
		type: "POST",
		success:function(data){
		$("#mail-status").html(data);
		},
		error:function (){}
		});
	}
}

function validateContact()
{

	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
	
	if(!$("#userName").val()) 
	{
		$("#userName-info").html("(required)");
		$("#userName").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#userName").val().match(/^[a-zA-z]/)) 
	{
		$("#userName-info").html("(Enter Only Latter)");
		$("#userName").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#userEmail").val()) 
	{
		$("#userEmail-info").html("(required)");
		$("#userEmail").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#userEmail").val().match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/)) 
	{
		$("#userEmail-info").html("(invalid)");
		$("#userEmail").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#subject").val()) 
	{
		$("#subject-info").html("(required)");
		$("#subject").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#subject").val().match(/^[a-zA-z0-9]/)) 
	{
		$("#subject-info").html("(Symbol is not allowed)");
		$("#subject").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#content").val()) 
	{
		$("#content-info").html("(required)");
		$("#content").css('background-color','#FFFFDF');
		valid = false;
	}
	
	return valid;
}
</script>
<body>


<div id="frmContact" class="container">
<div id="mail-status"></div>
<div class="panel panel-primary col-lg-6">
	<div class="panel panel-primary page-header">
   			<h2 class="text-center text-uppercase text-info"><marquee behavior="scroll" direction="left">Ajax Form Validation</marquee></h2>
    </div>
    
    <div class="panel-body">
	
        <div>
            <label>Name</label>
            <span id="userName-info" class="info"></span><br/>
            <input type="text" name="userName" class="form-control" id="userName" class="demoInputBox"/>
        </div>
        <div>
            <label>Email</label>
            <span id="userEmail-info" class="info"></span><br/>
            <input type="text" name="userEmail" id="userEmail" class="demoInputBox form-control"/>
        </div>
        <div>
            <label>Subject</label> 
            <span id="subject-info" class="info"></span><br/>
            <input type="text" name="subject" id="subject" class="demoInputBox form-control"/>
        </div>
        <div>
            <label>Content</label> 
            <span id="content-info" class="info"></span><br/>
            <textarea name="content" id="content" class="demoInputBox form-control" cols="60" rows="6"></textarea>
        </div>
        <div>
            <button name="submit" class="btnAction btn btn-group-lg btn-primary" onClick="sendContact();">Send</button>
        </div>
 
 </div>
</div>
</div>
</body>
</html>