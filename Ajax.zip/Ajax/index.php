<html>
<head>
<title>Ajax</title>
<link href="bootstrap/bootstrap.min.css" rel="stylesheet"/>
<script type="text/javascript" src="jquery-1.6.2.min.js">
</script>

<script type="text/javascript">

	function insert()
	{
		var name = $('#name').val();
		var email = $('#email').val();
			$.ajax({
					
					type: "POST",
					url: "ajax.php",
					data: {
						name:name, 
						email:email
						},
					success: function()
					{
						//alert("sucess Data Entry");
						window.location = "index.php";
					}
					
					});
    } 
	
</script>

<script type="application/javascript">

function fetch()
{
		$.ajax({
					
				type: "GET",
				url: "ajax1.php",
				data: "",
				success: function(data)
				{
					//alert("sucess Data Entry");
					
					$(".div1").html(data);
				}					
				});
  } 
	
</script>

</head>
<body>

   <br/>
   <br/>
<br/>
<div class="container">
	<div class="row">
		<div class=" col-lg-12">
			<div class="col-lg-6 panel panel-info">
    			<div class="panel-heading text-center text-uppercase"><h2>Ajax</h2></div>
        			<div class="panel-body">
                    
						<form action="" method="POST" class="form-group" autocomplete="off">
					  		Name:<input type="text" name="name" id="name" class="form-control" required="required"/><br />
                       		Email:<input type="text" name="email" id="email" class="form-control" required="required"/><br />
							<input type="button" onClick="insert();" name="submit" id="submit" class="btn btn-info" value="Submit" />  
						</form>  
            		</div>
        		</div>
			<div class="col-lg-6 panel panel-info">
    			<div class="panel-heading text-center text-uppercase"><h2>Ajax Retrive Data</h2></div>
        			<div class="panel-body">
						<form action="" method="GET">
                    		<input type="button" onClick="fetch();" name="btn" id="btn" class="btn btn-primary" value="Fetch" />
                    	</form>
                    
                    	<div class="div1"></div>
            		</div>
				</div>
    		</div>
		</div>
</div>
</body>
</html>