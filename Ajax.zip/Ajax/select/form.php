<html>
   <head>
 
       <script type="text/javascript" src="js/jquery-1.7.1.min.js"></script>
       <script type="text/javascript" src="js/jquery-ui-1.8.17.custom.min.js"></script>
        
       <script type="text/javascript">
              
 
                    function showComment(){
                      $.ajax({
                        type:"post",
                        url:"process.php",
                        data:"action=showcomment",
                        success:function(data){
                             $("#comment").html(data);
                        }
                      });
                    }
 
                    showComment();
               
       </script>
   </head>
 
   <body>
        <form action="form.php" method="post">
              
               <input type="button" onClick="showComment();" value="Send Comment" id="button">
                
               <div id="info"/>
               <ul id="comment"></ul>
        </form>
   </body>
</html>