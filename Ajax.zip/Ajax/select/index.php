<html>
  <head>
    <script language="javascript" type="text/javascript" src="../jquery-1.6.2.min.js"></script>
  </head>
  <body>

  
  <div id="output">Hello</div>

  <script id="source" language="javascript" type="text/javascript">

  $(function () 
  {
    
    $.ajax({                                      
      url: 'query.php',                  
      data: "",                       
                                       
      dataType: 'json',                  
      success: function(data)          
      {
        var id = data[0];             
        var vname = data[1];          
       
        $('#output').html("<b>id: </b>"+id+"<b> name: </b>"+vname); //Set output element html
       
      } 
    });
  }); 

  </script>
  </body>
</html>