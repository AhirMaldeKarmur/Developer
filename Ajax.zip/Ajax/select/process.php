<?php
  mysql_connect("localhost","root","");
  mysql_select_db("ajax");
 
   
  $action=$_POST["action"];
 
  if($action=="showcomment")
  {
     $show=mysql_query("Select * from employee order by id");
 
     while($row=mysql_fetch_array($show))
	 {
        echo "<li><b>$row[name]</b></li>";
     }
  }
  
?>