<?php 

  
  $host = "localhost";
  $user = "root";
  $pass = "";

  $con = mysql_connect($host,$user,$pass);
  $dbs = mysql_select_db('ajax', $con);
 
  $result = mysql_query("SELECT * FROM employee");          
  $array = mysql_fetch_row($result);                         
  
  echo json_encode($array);

?>