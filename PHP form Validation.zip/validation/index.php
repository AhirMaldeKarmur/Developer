
<?php
require_once "validation.php";
if(isset($_POST['btn']))
{
	
	$_SESSION['validation']=array();
	//validation for name
	$test = new validator();
	$test->name();
		
	
	
	//validation for email
	$test = new validator();
	$test->email();	
	
	//validation for mobile number
	$test =new validator();
	$test->mobile();		
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Form Validation</title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
<script src="bootstrap/bootbox/bootbox.min.js" type="application/javascript"></script>
</head>

<body>
<div class="container">
<div id="validation" class="col-lg-12">
<?php

	$test = new validator();
	$test->message();
?>
</div>
</div>
<br/>
<div class="container">
	<div class="col-lg-6 panel panel-info">
	<div class="panel-heading panel-primary">
		<h2 class="panel-title text-center">Form Validation</h2>
	</div>
	<div class="panel-body">
		<form action="index.php" method="post" enctype="multipart/form-data" class="form-group">

            <p><label>Name</label></p>
            <p><input type="text" name="txtname" id="txtname" class="form-control"/></p>
        
            <p><label>Email</label></p>
            <p><input type="text" name="txtemail" id="txtemail" class="form-control"/></p>
        
            <p><label>Mobile No</label></p>
            <p><input type="text" name="txtmo" id="txtmo" class="form-control"/></p>
        
            <p><input type="submit" name="btn" id="btn" value="Submit" class="btn btn-info"/></p>
		</form>
	</div>
	</div>
</div>
</body>
</html>