<?php

class validator
{
	public $name;
	public $email;
	public $mo_no;
	
	public function name()
	{
		if(empty($_POST['txtname']))
		{
			$_SESSION['validation'][] = "Name is required";
		}
		else
		{
			$this->name = $_POST['txtname'];
			if(!preg_match("/([a-zA-Z])/",$this->name))
			{
				$_SESSION['validation'][] = "name in enter only character";
			}
		}
	}
	
	public function email()
	{
		if(empty($_POST['txtemail']))
		{
			$_SESSION['validation'][] = "Email is required";
		}
		else
		{
			$this->email = $_POST['txtemail'];
			if(!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$this->email))
			{
				$_SESSION['validation'][] = "Enter Valide email";
			}
		}

	}
	
	public function mobile()
	{
		if(empty($_POST['txtmo']))
		{
			$_SESSION['validation'][] = "Mobile number is required";
		}
		else
		{
			$this->mo_no = $_POST['txtmo'];
		
			if(!preg_match("/([0-9])/",$this->mo_no))
			{
				$_SESSION['validation'][] = "Enter only number";
			}
		}
		
	}
	
	public function message()
	{
		if(isset($_SESSION['validation']))
		{
			echo "<ul>";
			foreach($_SESSION['validation'] as $validation):
				echo "<li  style='color:red'>".$validation."</li>";
			endforeach;	
			echo "</ul>";
			unset($_SESSION['validation']);
		}
	}
}

?>
