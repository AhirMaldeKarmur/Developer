<?php 
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>

<?php 
include("../quize/config.php");
 ?>
 <!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Class 1 Material</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link href="../bootstrap/bootstrap.min.css" rel="stylesheet"/>
</head>
<body>
<!--Create Navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top">
    	<div class="container">
        	<a class="navbar-brand" href="#">Study4You</a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
    			<span class="icon-bar"></span>
    			<span class="icon-bar"></span>
    			<span class="icon-bar"></span>
    		</button>
        		<div class="collapse navbar-collapse">	
         			<ul class="nav navbar-right navbar-nav">
            			<li><a href="../materialupload/index.php">Home</a></li>
                        <li><a href="../materialupload/view.php">View All Material</a></li>
            			<li class="active"><a href="">Class 1</a></li>
            			<li><a href="class2.php">Class 2</a></li>
            			<li><a href="class3.php">Class 3</a></li>
                        <li><a href="class4.php">Class 4</a></li>
                        <li><a href="class5.php">Class 5</a></li>
            			<li><a href="class5.php">Class 6</a></li>
            			<li><a href="class7.php">Class 7</a></li>
                        <li><a href="class8.php">Class 8</a></li>
                        <li><a href="class9.php">Class 9</a></li>
                        <li><a href="class10.php">Class 10</a></li>
         			</ul>
         		</div>
       </div>
   </div> 
		
<!--End Navbar -->

 <br/>
 <br/>
 <br/>
 <br/>
 <div class="container">
 <h2 class="text-center text-uppercase text-info">Class 1 Material</h2>
 <table width="80%" border="1" class="table table-responsive table-hover">
	<thead>
    <tr>
    <th colspan="5" class="text-center">your uploads...<label><a href="../materialupload/index.php">Add New Material</a></label></th>
    </tr>
    </thead>
    <tbody>
    <tr style="background-color:#36C; font-size:20px; color:#FFF;">
    <td>File Name</td>
    <td>File Type</td>
    <td>File Size(KB)</td>
    <td>Category</td>
    <td>View</td>
    </tr>
    <?php
		$class1 = mysql_query("SELECT * FROM material_upload WHERE category = 'std1'");
		$result = mysql_num_rows($class1); 
		
			while($row = mysql_fetch_array($class1))
			{ 
				$file = $row['file'];
             ?>
             <tr>
        		<td><?php echo $row['file_name'] ?></td>
        		<td><?php echo $row['type'] ?></td>
        		<td><?php echo $row['size'] ?></td>
                <td><?php echo $row['category'] ?></td>
        		<td><a href="../materialupload/upload/<?php echo $file ?>" target="_blank">Download</a></td>
        	</tr>
            <?php
    		}
mysql_close();

?>

</tbody>
</table>

</div>
</body>
</html>
