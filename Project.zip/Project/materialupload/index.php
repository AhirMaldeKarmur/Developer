<?php
include_once '../quize/config.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>File Uploading With PHP and MySql</title>
<link rel="stylesheet" href="style.css" type="text/css" />
<link rel="stylesheet" href="../bootstrap/bootstrap.min.css"/>
<script src="../bootstrap/jquery.js"></script>

</head>
<body>

<!--Create Navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top">
    	<div class="container">
        	<a class="navbar-brand" href="#">Study4You</a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
    			<span class="icon-bar"></span>
    			<span class="icon-bar"></span>
    			<span class="icon-bar"></span>
    		</button>
        		<div class="collapse navbar-collapse">	
         			<ul class="nav navbar-right navbar-nav header-bottom">
            			<li class="active"><a href="../materialupload/index.php">Home</a></li>
                        <li><a href="view.php">View All Material</a></li>  
            			<li><a href="../class/class1.php">Class 1</a></li>
            			<li><a href="../class/class2.php">Class 2</a></li>
            			<li><a href="../class/class3.php">Class 3</a></li>
                        <li><a href="../class/class4.php">Class 4</a></li>
                        <li><a href="../class/class5.php">Class 5</a></li>
            			<li><a href="../class/class5.php">Class 6</a></li>
            			<li><a href="../class/class7.php">Class 7</a></li>
                        <li><a href="../class/class8.php">Class 8</a></li>
                        <li><a href="../class/class9.php">Class 9</a></li>
                        <li><a href="../class/class10.php">Class 10</a></li>
         			</ul>
         		</div>
       </div>
   </div> 
		
<!--End Navbar -->


<!--content-->
<div class="special">
<div class="content_bg">
			<div class="main_pic">
				<a class="btn" href="#" >Study4You</a>
			<br/>
            <br/>

<div class="container">
	<div class="cont">
		<div class="content">
			<div class="content-top-bottom">
				<div class="col-md-6 men">
					<a href="../quize/index.php" class="b-link-stripe b-animate-go  thickbox"><img class="img-responsive" src="upload/31940-2.jpg" alt="">
						<div class="b-wrapper">
							<h3 class="b-animate b-from-top top-in   b-delay03 ">
								<span><button class="btn btn-info">Online OMR Exam</button></span>	
							</h3>
						</div>
					</a>
				</div>
                <div class="col-md-6 men">
					<a href="view.php" class="b-link-stripe b-animate-go  thickbox"><img class="img-responsive" src="upload/31940-2.jpg" alt="">
						<div class="b-wrapper">
							<h3 class="b-animate b-from-top top-in   b-delay03 ">
								<span><button class="btn btn-info">View All Material</button></span>	
							</h3>
						</div>
					</a>
				</div>
          </div>
      </div>
   </div>
<div class="container">
	
	<div class="panel panel-primary col-lg-12">
    	<div class="panel-heading">
        	<h2 class="text-center text-uppercase">Upload School Material</h2>
        </div>
        <div class="panel-body">
        	<form action="upload.php" method="post" class="form-group" enctype="multipart/form-data" autocomplete = "off">
            <label>Category</label>
    				<select name="category" class="form-control" required="required">
    						<option value=""></option>
                            <option value="std1">Class 1</option>
                            <option value="std2">Class 2</option>
                            <option value="std3">Class 3</option>
                            <option value="std4">Class 4</option>
                            <option value="std5">Class 5</option>
                            <option value="std6">Class 6</option>
                             <option value="std7">Class 7</option>
                            <option value="std8">Class 8</option>
                            <option value="std9">Class 9</option>
                            <option value="std10">Class 10</option>
    				</select><br/>
                    <input type="text" name="filename" id="filename" class="form-control" required="required"/><br/>
				<input type="file" name="file" class="form-control" required="required" /><br/>
			<button type="submit" class="btn btn-group-lg btn-info hvr-shutter-in-horizontal" name="btn-upload">Upload</button>
            <a href="view.php"><button type="button" class="btn btn-info hvr-shutter-in-horizontal">View Material</button></a>
           
		</form>
        </div>
			</div>
	</div>
</div>
</div>
</div>
</div>

    <?php
	if(isset($_GET['success']))
	{
		?>
        <label>File Uploaded Successfully...  <a href="view.php">click here to view file.</a></label>
        <?php
	}
	else if(isset($_GET['fail']))
	{
		?>
        <label>Problem While File Uploading !</label>
        <?php
	}
	else
	{
		?>
        <label>Try to upload any files(PDF, DOC, EXE, VIDEO, MP3, ZIP,etc...)</label>
        <?php
	}
	?>
</div>

</body>
</html>