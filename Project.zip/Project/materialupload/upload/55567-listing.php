
<?php 
include_once 'DBConfig.php';
class Listing
{  
	public $ListingID;
	public $UserID;
	public $DisplayName;
	public $ListingName;
	public $ListingTypeID;
	public $PhoneNo;
	public $Description;
	public $ImagePath;
	public $Address;
	public $Landmark;
	public $Pincode;
	public $City;
	public $State;
	public $Days;
	public $Timing;
	public $Days1;
	public $Timing1;
	public $Latitude;
	public $Longitude;
	public $OpeningHoursMonday;
	public $OpeningHoursTuesday;
	public $OpeningHoursWednesday;
	public $OpeningHoursThursday;
	public $OpeningHoursFriday;
	public $OpeningHoursSaturday;
	public $OpeningHoursSunday;
	public $ClosingHoursMonday;
	public $ClosingHoursTuesday;
	public $ClosingHoursWednesday;
	public $ClosingHoursThursday;
	public $ClosingHoursFriday;
	public $ClosingHoursSaturday;
	public $ClosingHoursSunday;
	public $OpeningHours1Monday;
	public $OpeningHours1Tuesday;
	public $OpeningHours1Wednesday;
	public $OpeningHours1Thursday;
	public $OpeningHours1Friday;
	public $OpeningHours1Saturday;
	public $OpeningHours1Sunday;
	public $ClosingHours1Monday;
	public $ClosingHours1Tuesday;
	public $ClosingHours1Wednesday;
	public $ClosingHours1Thursday;
	public $ClosingHours1Friday;
	public $ClosingHours1Saturday;
	public $ClosingHours1Sunday;
	public $OpeningHoursStatusMonday;
	public $OpeningHoursStatusTuesday;
	public $OpeningHoursStatusWednesday;
	public $OpeningHoursStatusThursday;
	public $OpeningHoursStatusFriday;
	public $OpeningHoursStatusSaturday;
	public $OpeningHoursStatusSunday;    
	public $Content;    
	public $Status;    
	public $WebLink;    
	public $Created;
	public $Modified;
	public $query;
	public $comment;
	public $allrating;
	/*Insert Method*/
	public function Insert() 
	{ 
		$InsertStr="INSERT INTO listing(
					UserID,
					DisplayName,
					ListingName,
					ListingTypeID,
					PhoneNo,
					ImagePath,
					Description,
					Address,
					Landmark,
					City,
					Pincode,
					State,
					Days,
					Timing,
					Days1,
					Timing1,
					Latitude,
					Longitude,
					OpeningHoursMonday,
					OpeningHoursTuesday,
					OpeningHoursWednesday,
					OpeningHoursThursday,
					OpeningHoursFriday,
					OpeningHoursSaturday,
					OpeningHoursSunday,
					ClosingHoursMonday,
					ClosingHoursTuesday,
					ClosingHoursWednesday,
					ClosingHoursThursday,
					ClosingHoursFriday,
					ClosingHoursSaturday,
					ClosingHoursSunday,
					OpeningHours1Monday,
					OpeningHours1Tuesday,
					OpeningHours1Wednesday,
					OpeningHours1Thursday,
					OpeningHours1Friday,
					OpeningHours1Saturday,
					OpeningHours1Sunday,
					ClosingHours1Monday,
					ClosingHours1Tuesday,
					ClosingHours1Wednesday,
					ClosingHours1Thursday,
					ClosingHours1Friday,
					ClosingHours1Saturday,
					ClosingHours1Sunday,
					Content,
					WebLink,
					Created,
					Modified)
		values (
					'".$this->UserID."'
					'".$this->DisplayName."'
					'".$this->ListingName."'
					'".$this->ListingTypeID."'
					'".$this->PhoneNo."'
					'".$this->ImagePath."'
					'".$this->Description."'
					'".$this->Address."'
					'".$this->Landmark."'
					'".$this->City."'
					'".$this->Pincode."'
					'".$this->State."'
					'".$this->Days."'
					'".$this->Timing."'
					'".$this->Days1."'
					'".$this->Timing1."'
					'".$this->Latitude."'
					'".$this->Longitude."'
					'".$this->OpeningHoursMonday."'
					'".$this->OpeningHoursTuesday."'
					'".$this->OpeningHoursWednesday."'
					'".$this->OpeningHoursThursday."'
					'".$this->OpeningHoursFriday."'
					'".$this->OpeningHoursSaturday."'
					'".$this->OpeningHoursSunday."'
					'".$this->ClosingHoursMonday."'
					'".$this->ClosingHoursTuesday."'
					'".$this->ClosingHoursWednesday."'
					'".$this->ClosingHoursThursday."'
					'".$this->ClosingHoursFriday."'
					'".$this->ClosingHoursSaturday."'
					'".$this->ClosingHoursSunday."'
					'".$this->OpeningHours1Monday."'
					'".$this->OpeningHours1Tuesday."'
					'".$this->OpeningHours1Wednesday."'
					'".$this->OpeningHours1Thursday."'
					'".$this->OpeningHours1Friday."'
					'".$this->OpeningHours1Saturday."'
					'".$this->OpeningHours1Sunday."'
					'".$this->ClosingHours1Monday."'
					'".$this->ClosingHours1Tuesday."'
					'".$this->ClosingHours1Wednesday."'
					'".$this->ClosingHours1Thursday."'
					'".$this->ClosingHours1Friday."'
					'".$this->ClosingHours1Saturday."'
					'".$this->ClosingHours1Sunday."'
					'".$this->Content."'  
					'".$this->WebLink."'  
					'".date('Y-m-d H:i:s')."',
					'".date('Y-m-d H:i:s')."')";
		if(mysqli_query($this->Conn,$InsertStr))  
		{ 
			return true; 
		} 
		else 
		{ 
			return false; 
		}  
	}
	/*Select All Data Method*/
	public function SelectAll() 
	{ 
		$SelectStr=" SELECT 
				listing.*
				FROM listing ORDER BY listing.ListingID DESC";
		if($SelectAllResult=mysqli_query($this->Conn,$SelectStr))  
		{ 
			return $SelectAllResult; 
		} 
		else 
		{ 
			return null; 
		}  
	}

	public function SelectByListingTypeIDs() 
	{ 
		$SelectStr=" SELECT 
				listing.ListingTypeID,
				listing.ListingID,
				listing.ListingName,
				listing.ImagePath,
				listing.Description,
				listing.Address,
				listing.Landmark,
				listing.Pincode,
				listing.City,
				listing.State,
				listing.Days,
				listing.Timing,
				listing.Days1,
				listing.Timing1,
				listing.Latitude,
				listing.Longitude,
				listing.OpeningHoursMonday,
				listing.OpeningHoursTuesday,
				listing.OpeningHoursWednesday,
				listing.OpeningHoursThursday,
				listing.OpeningHoursFriday,
				listing.OpeningHoursSaturday,
				listing.OpeningHoursSunday,
				listing.closingHoursMonday,
				listing.closingHoursTuesday,
				listing.closingHoursWednesday,
				listing.closingHoursThursday,
				listing.closingHoursFriday,
				listing.closingHoursSaturday,
				listing.closingHoursSunday,
				listing.OpeningHoursStatusMonday,
				listing.OpeningHoursStatusTuesday,
				listing.OpeningHoursStatusWednesday,
				listing.OpeningHoursStatusThursday,
				listing.OpeningHoursStatusFriday,
				listing.OpeningHoursStatusSaturday,
				listing.OpeningHoursStatusSunday,  
				listing.Content,
				listing.Status,
				listing.WebLink,
				listing.Created,
				listing.Modified
				FROM listing WHERE listing.ListingTypeID = ".$this->ListingTypeID." ORDER BY listing.ListingID DESC";
		if($SelectAllResult=mysqli_query($this->Conn,$SelectStr))  
		{ 
			return $SelectAllResult; 
		} 
		else 
		{ 
			return null; 
		}  
	}

	public function SelectByListingTypeIDAndStatus() 
	{ 
		$SelectStr=" SELECT 
				listing.ListingTypeID,
				listing.ListingID,
				listing.ListingName,
				listing.ImagePath,
				listing.Description,
				listing.Address,
				listing.Landmark,
				listing.Pincode,
				listing.City,
				listing.State,
				listing.Days,
				listing.Timing,
				listing.Days1,
				listing.Timing1,
				listing.Latitude,
				listing.Longitude,
				listing.OpeningHoursMonday,
				listing.OpeningHoursTuesday,
				listing.OpeningHoursWednesday,
				listing.OpeningHoursThursday,
				listing.OpeningHoursFriday,
				listing.OpeningHoursSaturday,
				listing.OpeningHoursSunday,
				listing.closingHoursMonday,
				listing.closingHoursTuesday,
				listing.closingHoursWednesday,
				listing.closingHoursThursday,
				listing.closingHoursFriday,
				listing.closingHoursSaturday,
				listing.closingHoursSunday,
				listing.OpeningHoursStatusMonday,
				listing.OpeningHoursStatusTuesday,
				listing.OpeningHoursStatusWednesday,
				listing.OpeningHoursStatusThursday,
				listing.OpeningHoursStatusFriday,
				listing.OpeningHoursStatusSaturday,
				listing.OpeningHoursStatusSunday,  
				listing.Content,
				listing.Status,
				listing.WebLink,
				listing.Created,
				listing.Modified
				FROM listing WHERE listing.ListingTypeID = $this->ListingTypeID ORDER BY listing.ListingID DESC";
		if($SelectAllResult=mysqli_query($this->Conn,$SelectStr))  
		{ 
			return $SelectAllResult; 
		} 
		else 
		{ 
			return null; 
		}  
	}

	public function SelectByStatus() 
	{ 
		$SelectStr=" SELECT 
				listing.ListingTypeID,
				listing.ListingID,
				listing.ListingName,
				listing.ImagePath,
				listing.Description,
				listing.Address,
				listing.Landmark,
				listing.Pincode,
				listing.City,
				listing.State,
				listing.Days,
				listing.Timing,
				listing.Days1,
				listing.Timing1,
				listing.Latitude,
				listing.Longitude,
				listing.OpeningHoursMonday,
				listing.OpeningHoursTuesday,
				listing.OpeningHoursWednesday,
				listing.OpeningHoursThursday,
				listing.OpeningHoursFriday,
				listing.OpeningHoursSaturday,
				listing.OpeningHoursSunday,
				listing.closingHoursMonday,
				listing.closingHoursTuesday,
				listing.closingHoursWednesday,
				listing.closingHoursThursday,
				listing.closingHoursFriday,
				listing.closingHoursSaturday,
				listing.closingHoursSunday,
				listing.OpeningHoursStatusMonday,
				listing.OpeningHoursStatusTuesday,
				listing.OpeningHoursStatusWednesday,
				listing.OpeningHoursStatusThursday,
				listing.OpeningHoursStatusFriday,
				listing.OpeningHoursStatusSaturday,
				listing.OpeningHoursStatusSunday,  
				listing.Content,
				listing.Status,
				listing.WebLink,
				listing.Created,
				listing.Modified
				FROM listing WHERE listing.Status = $this->Status ORDER BY listing.ListingID DESC";
		if($SelectAllResult=mysqli_query($this->Conn,$SelectStr))  
		{ 
			return $SelectAllResult; 
		} 
		else 
		{ 
			return null; 
		}  
	}

	/*Select Data for Combobox*/
   public function SelectComboBox() 
	{ 
		$SelectStr=" SELECT listing.*,Listingtype.ListingTypeName,user.Name FROM listing LEFT JOIN Listingtype ON Listingtype.ListingTypeID=listing.ListingTypeID LEFT JOIN user ON user.UserID=listing.UserID ORDER BY listing.ListingID DESC";
		 if($SelectAllResult=mysqli_query($this->Conn,$SelectStr))  
		 { 
			 return $SelectAllResult; 
		 } 
		 else 
		 { 
			 return null; 
		 }  
	 }
	/*Select Data for Combobox*/
	public function SelectAlllisting() 
	{ 
		$SelectStr=" SELECT listing.*,user.Name FROM listing LEFT JOIN user ON user.UserID=listing.UserID LEFT JOIN Listingmembers ON Listingmembers.ListingID=listing.ListingID WHERE Listingmembers.UserID = $this->UserID ORDER BY listing.ListingID DESC";
		if($SelectAllResult=mysqli_query($this->Conn,$SelectStr))  
		{ 
			return $SelectAllResult; 
		} 
		else 
		{ 
			return null; 
		}  
	}

	public function SelectByPK($ListingID) 
	{ 
		 $SelectStr="SELECT 
				listing.*,
				listingrating.RatingCount,
				listingrating.Comment,
				AVG(listingrating.RatingCount) AS Rating,
				COUNT(listingrating.RatingCount) AS TotalUser
				FROM listing LEFT JOIN listingtype ON listingtype.ListingTypeID=listing.ListingTypeID LEFT JOIN listingrating ON listingrating.ListingID=listing.ListingID WHERE listing.ListingID=".$ListingID;
				
				
		if($SelectPKResult=mysql_query($SelectStr))  
		{ 
			return mysql_fetch_array($SelectPKResult); 
		} 
		else 
		{ 
			return null;
		}  
		
	 }
	 public function runQuery($query) 
	 {
		 $query ="SELECT RatingCount FROM listingrating where ListingID=".base64_decode(base64_decode($_GET['ListingID']));
		$result = mysql_query($query);
		while($row=mysql_fetch_assoc($result)) 
		{
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	} 
	
	function rating($allrating) {
		$allrating ="SELECT listingrating.RatingCount,listingrating.Comment,listing.DisplayName,listing.ImagePath FROM listingrating,listing where listing.ListingID = listingrating.ListingID";
		$result = mysql_query($allrating);
		while($row=mysql_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
	
	
	
	public function SelectByKeyword($Keyword){ 
		$SelectStr="SELECT listing.*,
				listingtype.ListingTypeName
				FROM listing, listingtype
				WHERE listing.ListingTypeID = listingtype.ListingTypeID AND (listing.ListingName LIKE '%$Keyword%' OR listingtype.ListingTypeName LIKE '%$Keyword%') ORDER BY listing.ListingID DESC";
		if($SelectPKResult=mysqli_query($this->Conn,$SelectStr))  
		{ 
		 return $SelectPKResult; 
		} 
		else 
		{ 
			return null; 
		}  
	}
	
	public function SelectByUser() 
	{ 
		$SelectStr="SELECT 
				listing.*,
				listingtype.ListingTypeName
				FROM listing LEFT JOIN listingtype ON listingtype.ListingTypeID=listing.ListingTypeID WHERE listing.UserID=$this->UserID";
		if($SelectPKResult=mysqli_query($this->Conn,$SelectStr))  
		{ 
			return $SelectPKResult; 
		} 
		else 
		{ 
			return null; 
		}  
	 }
	 
	public function SelectListingMembers() 
	{ 
		$SelectStr="select user.Name,user.ProfileImage,user.UserID,listing.ListingID,Listingmembers.Status FROM user,listing,Listingmembers WHERE listing.ListingID = Listingmembers.ListingID AND Listingmembers.UserID = user.UserID AND listing.ListingID = $this->ListingID AND Listingmembers.Status <> 2";
		if($SelectPKResult=mysqli_query($this->Conn,$SelectStr))  
		{ 
			return $SelectPKResult; 
		} 
		else 
		{ 
			return null; 
		}  
	 }
	 
	public function ListingDetails() 
	{ 
		$SelectStr="select listing.*, count(Listingmembers.ListingID) AS TotalMember,Listingtype.ListingTypeName FROM user,listing,Listingmembers,Listingtype WHERE listing.ListingID = Listingmembers.ListingID AND Listingtype.ListingTypeID = listing.ListingTypeID AND Listingmembers.UserID = user.UserID AND listing.ListingID = $this->ListingID AND Listingmembers.Status <> 2";
		if($SelectPKResult=mysqli_query($this->Conn,$SelectStr))  
		{ 
			return $SelectPKResult; 
		} 
		else 
		{ 
			return null; 
		}  
	 }
	 
	 public function SelectByListingTypeID($ListingTypeID) 
	{ 
		$SelectStr=" SELECT ListingName FROM user where ListingTypeID= '$ListingTypeID'";
		 if($SelectPKResult=mysqli_query($this->Conn,$SelectStr))  
		 { 
			 return $SelectPKResult; 
		 } 
		 else 
		 { 
			 return null; 
		 }  
	 }
	 
	public function SelectByName($ListingName) 
	{ 
		 $SelectStr="SELECT * FROM listing where ListingName='$ListingName'";
		 if($SelectPKResult=mysqli_query($this->Conn,$SelectStr))  
		 { 
			 return $SelectPKResult; 
		 } 
		 else 
		 { 
			 return null; 
		 }  
	 }

	public function Delete() 
	{ 
		$DeleteStr="DELETE FROM listing where ListingID=$this->ListingID";
		 if(mysqli_query($this->Conn,$DeleteStr))  
		 { 
			 return true; 
		 } 
		 else 
		 { 
			 return false; 
		 }  
	 }

	public function Update() 
	{ 
		$UpdateStr="UPDATE listing SET 
						DisplayName='$this->DisplayName',
						ListingName='$this->ListingName',
						ListingTypeID='$this->ListingTypeID',
						PhoneNo='$this->PhoneNo',
						Description='$this->Description',
						Address='$this->Address',
						Landmark='$this->Landmark',
						Pincode='$this->Pincode',
						State='$this->State',
						City='$this->City',
						OpeningHoursMonday='$this->OpeningHoursMonday',
						OpeningHoursTuesday='$this->OpeningHoursTuesday',
						OpeningHoursWednesday='$this->OpeningHoursWednesday',
						OpeningHoursThursday='$this->OpeningHoursThursday',
						OpeningHoursFriday='$this->OpeningHoursFriday',
						OpeningHoursSaturday='$this->OpeningHoursSaturday',
						OpeningHoursSunday='$this->OpeningHoursSunday',
						ClosingHoursMonday='$this->ClosingHoursMonday',
						ClosingHoursTuesday='$this->ClosingHoursTuesday',
						ClosingHoursWednesday='$this->ClosingHoursWednesday',
						ClosingHoursThursday='$this->ClosingHoursThursday',
						ClosingHoursFriday='$this->ClosingHoursFriday',
						ClosingHoursSaturday='$this->ClosingHoursSaturday',
						ClosingHoursSunday='$this->ClosingHoursSunday',
						OpeningHours1Monday='$this->OpeningHours1Monday',
						OpeningHours1Tuesday='$this->OpeningHours1Tuesday',
						OpeningHours1Wednesday='$this->OpeningHours1Wednesday',
						OpeningHours1Thursday='$this->OpeningHours1Thursday',
						OpeningHours1Friday='$this->OpeningHours1Friday',
						OpeningHours1Saturday='$this->OpeningHours1Saturday',
						OpeningHours1Sunday='$this->OpeningHours1Sunday',
						ClosingHours1Monday='$this->ClosingHours1Monday',
						ClosingHours1Tuesday='$this->ClosingHours1Tuesday',
						ClosingHours1Wednesday='$this->ClosingHours1Wednesday',
						ClosingHours1Thursday='$this->ClosingHours1Thursday',
						ClosingHours1Friday='$this->ClosingHours1Friday',
						ClosingHours1Saturday='$this->ClosingHours1Saturday',
						ClosingHours1Sunday='$this->ClosingHours1Sunday',
						Days='$this->Days',
						Timing='$this->Timing',
						Days1='$this->Days1',
						Timing1='$this->Timing1',
						Content = '$this->Content',
						Latitude = '$this->Latitude',
						Longitude = '$this->Longitude',
						WebLink = '$this->WebLink',
						Modified='".date('Y-m-d H:i:s')."' WHERE ListingID=$this->ListingID";
		 if(mysqli_query($this->Conn,$UpdateStr))  
		 { 
			 return true; 
		 } 
		 else 
		 { 
			 return false; 
		}
	} 
	
	public function UpdateWithImage() 
	{ 
		$UpdateStr="UPDATE listing SET 
						DisplayName='$this->DisplayName',
						ListingName='$this->ListingName',
						ListingTypeID='$this->ListingTypeID',
						PhoneNo='$this->PhoneNo',
						Description='$this->Description',
						ImagePath='$this->ImagePath',
						Address='$this->Address',
						Landmark='$this->Landmark',
						Pincode='$this->Pincode',
						State='$this->State',
						City='$this->City',
						OpeningHoursMonday='$this->OpeningHoursMonday',
						OpeningHoursTuesday='$this->OpeningHoursTuesday',
						OpeningHoursWednesday='$this->OpeningHoursWednesday',
						OpeningHoursThursday='$this->OpeningHoursThursday',
						OpeningHoursFriday='$this->OpeningHoursFriday',
						OpeningHoursSaturday='$this->OpeningHoursSaturday',
						OpeningHoursSunday='$this->OpeningHoursSunday',
						ClosingHoursMonday='$this->ClosingHoursMonday',
						ClosingHoursTuesday='$this->ClosingHoursTuesday',
						ClosingHoursWednesday='$this->ClosingHoursWednesday',
						ClosingHoursThursday='$this->ClosingHoursThursday',
						ClosingHoursFriday='$this->ClosingHoursFriday',
						ClosingHoursSaturday='$this->ClosingHoursSaturday',
						ClosingHoursSunday='$this->ClosingHoursSunday',
						OpeningHours1Monday='$this->OpeningHours1Monday',
						OpeningHours1Tuesday='$this->OpeningHours1Tuesday',
						OpeningHours1Wednesday='$this->OpeningHours1Wednesday',
						OpeningHours1Thursday='$this->OpeningHours1Thursday',
						OpeningHours1Friday='$this->OpeningHours1Friday',
						OpeningHours1Saturday='$this->OpeningHours1Saturday',
						OpeningHours1Sunday='$this->OpeningHours1Sunday',
						ClosingHours1Monday='$this->ClosingHours1Monday',
						ClosingHours1Tuesday='$this->ClosingHours1Tuesday',
						ClosingHours1Wednesday='$this->ClosingHours1Wednesday',
						ClosingHours1Thursday='$this->ClosingHours1Thursday',
						ClosingHours1Friday='$this->ClosingHours1Friday',
						ClosingHours1Saturday='$this->ClosingHours1Saturday',
						ClosingHours1Sunday='$this->ClosingHours1Sunday',
						Days='$this->Days',
						Timing='$this->Timing',
						Days1='$this->Days1',
						Timing1='$this->Timing1',
						Content='$this->Content',
						Latitude='$this->Latitude',
						Longitude='$this->Longitude',
						WebLink='$this->WebLink',
						Modified='".date('Y-m-d H:i:s')."' WHERE ListingID=$this->ListingID";
		 if(mysqli_query($this->Conn,$UpdateStr))  
		 { 
			 return true; 
		 } 
		 else 
		 { 
			 return false; 
		}
	} 
	
	public function PasswordUpdate() 
	{ 
		$UpdateStr="UPDATE Listing SET 
						Password='$this->Password',
						Modified='".date('Y-m-d H:i:s')."' WHERE ListingID=$this->ListingID";
		 if(mysqli_query($this->Conn,$UpdateStr))  
		 { 
			 return true; 
		 } 
		 else 
		 { 
			 return false; 
		}
	} 
	
	public function UpdateDescription() 
	{ 
		$UpdateStr="UPDATE listing SET 
						Description='$this->Description',
						Modified='".date('Y-m-d H:i:s')."' WHERE ListingID=$this->ListingID";
		 if(mysqli_query($this->Conn,$UpdateStr))  
		 { 
			 return true; 
		 } 
		 else 
		 { 
			 return false; 
		}
	} 
	
	public function SetStatus($Date) 
	{ 
		$UpdateStr="UPDATE listing SET 
					$Date='$this->Status',
					Modified='".date('Y-m-d H:i:s')."' WHERE ListingID=$this->ListingID";
		 if(mysqli_query($this->Conn,$UpdateStr))  
		 { 
			 return true; 
		 } 
		 else 
		 { 
			 return false; 
		}
	} 
}  
?>