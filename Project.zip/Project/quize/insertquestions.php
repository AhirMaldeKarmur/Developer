<?php
require 'config.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<link href="../bootstrap/bootstrap.min.css" rel="stylesheet"/>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>
<div class="container">
	<div class="col-lg-8">
    	<div class="panel panel-primary">
        	<div class="panel-heading panel-info">
            	<h2 class="text-center">Enter Exam Questions</h2>
            </div>
            <div class="panel-body">
                    <form method="post" action="insertquestions.php" class="form-group">
                    <label>Question :</label>
                    <input type="text" class="form-control" name="txtque" placeholder="enter question here"/>
                    <br />
                    <label>Option Answer1 : </label>
                    <input type="text" class="form-control" name="txtans1" placeholder="enter Answer 1 here" required />
                    <br />
                    <label>Option Answer2 : </label>
                    <input type="text" class="form-control" name="txtans2" placeholder="enter Answer 2 here" />
                    <br />
                    <label>Option Answer3 : </label>
                    <input type="text" class="form-control"  name="txtans3" placeholder="enter Answer 3 here"/>
                    <br />
                    <label>Option Answer4 : </label>
                    <input type="text" class="form-control" name="txtans4" placeholder="enter Answer 4 here"/>
                    <br />
                    <label>Correct Answer : </label>
                    <select name="txtans" class="form-control">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    </select>
                    <br />
                    <label>Category Id : </label>
                       
                    <select name="txtcat_id" class="form-control">
                        <?php $query = mysql_query("select * from categories "); 
                            while ($row = mysql_fetch_array($query)) 
                            {
                                $id=$row['id'];
                                $category_name=$row['category_name'];
                                echo '<option value="'.$row['id'].'">'.$row['category_name'].'</option>';
                            } 
                        ?>
                     </select>    
                        <?php
                            if(isset($_POST['submit']))
                            {
                                $qry = mysql_query("INSERT INTO `questions` (question_name,answer1,answer2,answer3,answer4,answer,category_id) 
                                VALUES ('".$_POST['txtque']."','".$_POST['txtans1']."','".$_POST['txtans2']."','".$_POST['txtans3']."','".$_POST[                                        'txtans4']."','".$_POST['txtans']."','".$_POST['txtcat_id']."')");
                    
                            }
                        ?>
                    <br>
                    <input type="submit" class="btn btn-info center-block" name="submit" value="submit"/>
                    </form>
    		</div>
    	</div>
    </div>
</div>    
</body>
</html>