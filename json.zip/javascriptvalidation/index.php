<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Java Script Form Validation</title>
<link href="../validation/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
<script src="../validation/bootstrap/bootbox/bootbox.min.js" type="application/javascript"></script>

<script>

function validation()
{
	var uname = document.getElementById('txtname').value;
	var uemail = document.getElementById('txtemail').value;
	var umo_no = document.getElementById('txtmo').value;
	
	var name_l = RegExp(/^[A-Za-z]+$/);
	var email_l = RegExp(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/);
	var mobile_l = RegExp(/^[0-9]+$/);
		
	if(!uname.match(name_l))
	{
		alert("Enter only character");
	}
	if(!uemail.match(email_l))
	{
		alert("Enter velide email");
	}
	if(!umo_no.match(mobile_l))
	{
		alert("Enter only Number");
	}
}

</script>
</head>
<body>
<div class="container">
	<div class="col-lg-6 panel panel-success">
    	<div class="panel-heading">
    		<h2 class="panel-title text-center text-warning">Form Validation</h2>
    	</div>
    <div class="panel-body">
		<form class="form-group" action="index.php" method="post" enctype="multipart/form-data">
			
            <p><label>Name</label></p>
    		<p><input type="text" name="txtname" id="txtname" class="form-control"/></p>
            
            <p><label>Email</label></p>
    		<p><input type="text" name="txtemail" id="txtemail" class="form-control"/></p>
            
            <p><label>Mobile No</label></p>
    		<p><input type="text" name="txtmo" id="txtmo" class="form-control"/></p>
            
            <P><input type="submit" class="btn btn-primary" name="submit" id="submit" value="Submit" onclick="return validation();"/></P>
		</form>
    </div>
	</div>
</div>
</body>
</html>