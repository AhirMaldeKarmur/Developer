<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="jquery.js"></script>
<script src="jquery.validation.js"></script>
<link href="bootstrap/bootstrap.min.css" rel="stylesheet"/>

<script>
(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            
            $("#register-form").validate({
                rules: {
                    firstname: "required",
                    lastname: "required",
                    email: {
                        required: true,
                        email: true
                    },
                    password: {
                        required: true,
                        minlength: 5
                    },
                    agree: "required"
                },
                messages: {
                    firstname: "Please enter your firstname",
                    lastname: "Please enter your lastname",
                    password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 5 characters long"
                    },
                    email: "Please enter a valid email address",
                    agree: "Please accept our policy"
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
</script>

<style>
.error
{
	color:#F00;
	font-size:9px;
}
</style>

</head>

<body>
<br/>
<br/>
<div class="container">
<div class="col-lg-6 panel panel-info">
	<div class="panel-heading">
    <h2 class="panel-title text-center">User Registration</h2>
    </div>
    <div class="panel-body">
<form action="" method="post" id="register-form" class="form-group">

    <div id="form-content">
        <fieldset>
            <div class="fieldgroup">
                <label for="firstname">First Name</label>
                <input type="text" name="firstname" class="form-control"/>
            </div>

            <div class="fieldgroup">
                <label for="lastname">Last Name</label>
                <input type="text" name="lastname" class="form-control"/>
            </div>

            <div class="fieldgroup">
                <label for="email">Email</label>
                <input type="text" name="email" class="form-control"/>
            </div>

            <div class="fieldgroup">
                <label for="password">Password</label>
                <input type="password" name="password" class="form-control"/>
            </div>
			<br/>
            <div class="fieldgroup">
                <input type="submit" value="submit" class="submit btn btn-primary"/>
            </div>

        </fieldset>
    </div>
	
</form>
</div>
</div>
</div>
</body>
</html>