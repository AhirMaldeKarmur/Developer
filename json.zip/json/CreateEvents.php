
<?php
	include_once 'Mywork/connect.php';
	include_once 'Mywork/insert.php';
	
	$objEvents= new abc();
	
	$objEvents->name = isset($_REQUEST['name']) ? $_REQUEST['name'] : '';
	$objEvents->email = isset($_REQUEST['email']) ? $_REQUEST['email'] : '';
	$objEvents->pass  = isset($_REQUEST['password']) ? $_REQUEST['password'] : '';
	
	
	if($objEvents->name == ""){
		echo json_encode(array("success"=>false,"msg"=>"Please select Name"));
		exit;
	}elseif($objEvents->email == ""){
		echo json_encode(array("success"=>false,"msg"=>"Please select Email"));
		exit;
	}elseif($objEvents->pass == ""){
		echo json_encode(array("success"=>false,"msg"=>"Please enter Password"));
		exit;
	}
	// elseif(date('Y-m-d H:i:s',strtotime($objEvents->FromDate)) < date('Y-m-d H:i:s')){
		// echo json_encode(array("success"=>false,"msg"=>"From date should be greater than or current date"));
		// exit;
	// }elseif(date('Y-m-d H:i:s',strtotime($objEvents->ToDate)) < date('Y-m-d H:i:s')){
		// echo json_encode(array("success"=>false,"msg"=>"To date should be greater than or current date"));
		// exit;
	// }elseif($objEvents->FromDate > $objEvents->ToDate){
		// echo json_encode(array("success"=>false,"msg"=>"To date should be greater than from date"));
		// exit;
	// }
	/*
	if(isset($_FILES['Image']['name']) && !empty($_FILES['Image']['name'])){
		$info = explode(".",$_FILES['Image']['name']);
		$ext = end($info); // get the extension of the file
		$filename = "Event-".time().'.'.$ext;
		
		if(!empty($_FILES['Image']['name']) && !IsValidImageFile($_FILES['Image']['name'])){
			$ErrorMsg.="Upload Only Image File.";
		}else if(!move_uploaded_file($_FILES['Image']['tmp_name'],'../Master/Upload/Event/'.$filename)){
			$ErrorMsg.="Something wrong in uploading File";
		}else{
			$objEvents->EventImage = $filename;
		}
	}else{
		$objEvents->EventImage = "";
	}
	*/
	if($objEvents->insert())
	{
		echo json_encode(array("success"=>true,"msg"=>"insert data successfully"));
	}
	else
	{
		echo json_encode(array("success"=>false,"msg"=>"Technical Error"));
	}
?>