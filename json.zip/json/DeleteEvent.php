<?php
	include_once 'Mywork/connect.php';
	include_once 'Mywork/insert.php';
	
	$objEvents= new abc();
	
	$objEvents->name = isset($_REQUEST['name']) ? $_REQUEST['name'] : '';
	
	if($objEvents->name == ""){
		echo json_encode(array("success"=>false,"msg"=>"Please select Name"));
		exit;
	}
	// $objResultEvent = $objEvents->SelectByPK();
	// $objRow=mysqli_fetch_assoc($objResultEvent);
	// if($objRow['EventImage'] != ""){
		
	// }
	if($objResult = $objEvents->delete())
	{
		echo json_encode(array("success"=>true,"msg"=>"Romeve successfully"));
		exit;
	}
	else
	{
		echo json_encode(array("success"=>false,"msg"=>"Technical Error"));
		exit;
	}
?>