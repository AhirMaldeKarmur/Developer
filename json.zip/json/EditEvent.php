<?php
	include_once 'Mywork/connect.php';
	include_once 'Mywork/insert.php';
	
	$objEvents= new abc();
	$objEvents->name = isset($_REQUEST['name']) ? $_REQUEST['name'] : '';
	$objEvents->email = isset($_REQUEST['email']) ? $_REQUEST['email'] : '';
	$objEvents->pass  = isset($_REQUEST['password']) ? $_REQUEST['password'] : '';
	
	if($objEvents->name == ""){
		echo json_encode(array("success"=>false,"msg"=>"Please select Name"));
		exit;
	}elseif($objEvents->email == ""){
		echo json_encode(array("success"=>false,"msg"=>"Please select Email"));
		exit;
	}elseif($objEvents->pass == ""){
		echo json_encode(array("success"=>false,"msg"=>"Please select Password"));
		exit;
	}
	
		if($objEvents->update())
		{
			echo json_encode(array("success"=>true,"msg"=>"Events updated successfully"));
		}
		else
		{
			echo json_encode(array("success"=>false,"msg"=>"Technical Error"));
			
		}
	
?>