<?php
	include_once 'Mywork/connect.php';
	include_once 'Mywork/insert.php';
	
	$objEvents= new abc();
	
	$objEvents->id = isset($_REQUEST['id']) ? $_REQUEST['id'] : '';
	
	if($objEvents->id == "")
	{
		
		echo json_encode(array("success"=>false,"msg"=>"Please select ID"));
		exit;
	
	}
	
	$objResult=$objEvents->selectbyname($objEvents->id);

	if(isset($objResult) and $objResult!=null)
	
	{
		if(mysql_num_rows($objResult)>0)
		
		{
			
			$objRow=mysql_fetch_assoc($objResult);
			
			$id = isset($objRow['id']) ? $objRow['id'] : "";
			$name = isset($objRow['name']) ? $objRow['name'] : "";
			$email = isset($objRow['email']) ? $objRow['email'] : "";
			$message = isset($objRow['message']) ? $objRow['message'] : "";
			
			$json[] = array(
				'id' => $id,
				'name' => $name,
				'email' => $email,
				'message' => $message	
			);
			
			echo json_encode(array("success"=>true,"msg"=>$json));
		}
		else
		{
			
			echo json_encode(array("success"=>false,"msg"=>"No Events Found"));
		
		}
	
	}
	else
	{
		
		echo json_encode(array("success"=>false,"msg"=>"Technical Error"));
	
	}
?>