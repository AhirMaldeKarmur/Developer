<?php
require_once "connect.php";
require_once "insert.php";

$user = new abc();
$user->name = $_GET['name'];
$result = $user->delete();
if($result)
{
	?>
    <script>
	alert("Delete your record");
	window.location = "form.php";
	</script>
    <?php
}
else
{
	?>
    <script>
	alert("Error..! Not Delete your record");
	window.location = "form.php";
	</script>
    <?php
}
return $user;
?>