
<?php
require_once 'insert.php';
if(isset($_POST['Submit']))
{
	$test = new abc();
	$test->name = $_POST['name'];
	$test->email = $_POST['email'];
	$test->pass = $_POST['pass'];
	$test->insert();
}
?>

<?php
$user = new abc();
$result = $user->display();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insert Data</title>
</head>

<body>

<table border="1">
	<tr>
		<th>Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Delete</th>
        <th>Update</th>
	</tr>
    <?php
	foreach($result as $data)
	{
		echo "<tr>";
		echo "<td>".$data['name']."</td>";
		echo "<td>".$data['email']."</td>";
		echo "<td>".$data['password']."</td>";
		echo "<td><a href='delete.php?name=".$data['name']."'>Delete</a>";
		echo "<td><a href='update.php?name=".$data['name']."'>Edit</a>";
		echo "</tr>";
	}
	?>
</table>
<br/>
<form class="form-group" name="input" action="form.php" method="post" autocomplete = "off">
                     
                     <label for="name">Name</label>
                     <input type="text" class="form-control" name="name" id="name" required/>
                     
                     <label for="email">Email</label>
                     <input type="text" class="form-control" name="email" id="email" required />
                     
                     <label for="comment">Password</label>
                     <input type="password" class="form-control" name="pass" id="pass" required />

                     <input type="submit" name="Submit" id="btn" value="Submit" />
      
</form>

</body>
</html>
