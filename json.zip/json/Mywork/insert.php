<?php

require_once "connect.php";

class abc
{
	public $name;
	public $email;
	public $pass;
	public $id;
	
	public function insert()
	{
		$insert = "INSERT INTO `signup` (name,email,password) VALUES('".$this->name."','".$this->email."','".$this->pass."')";
		$sql = mysql_query($insert);
		if($sql)
		{
			$result = "succse";
		}
		else
		{
			$result = "error";
		}
		return $result;
	}
	public function display()
	{
		$select = "select * from signup";
		$query = mysql_query($select);
		while($row = mysql_fetch_array($query))
		{
			$result[] = $row;
		}
		return $result;
	}
	public function selectbyname($id)
	{
		$select = "SELECT * FROM `contact` WHERE `id` = $id";
		
		if($Result=mysql_query($select ))
		{
			return $Result;
		
		}
		else
		{
			return null;
		
		}
		
	}
	
	public function delete()
	{
		$delete = "delete from signup where name ='".$this->name."'";
		$query = mysql_query($delete);
		return $query;
		
	}
	
	public function update()
	{
		$update = "UPDATE `signup` SET `email`='".$this->email."',`password`='".$this->pass."' WHERE `name`='".$this->name."'";
		$query = mysql_query($update);
		return $query;
	}
}

?>