<?php
require_once "connect.php";
require_once "insert.php";

$user = new abc();
$user->name = $_GET['name'];
if(isset($_POST['submit']))
{
	$result = $user->update();
	if($result)
	{
		?>
        <script>
		alert("record is update");
		window.location = 'form.php'
		</script>
        <?php
	}
	else
	{
		?>
        <script>
		alert("error in update record");
		window.location = 'form.php'
		</script>
        <?php
	}
}
if($_GET['name']!="")
{
	$row = $user->selectbyname();
	echo '<pre>';

}
?>

<html>
<head>
<title>Update data</title>
</head>
<body>
<form name="input" action="form.php" method="post" autocomplete = "off">
                     
                     <label for="name">Name</label>
                     <input type="text" name="name" id="name" value="<?php echo isset($row['name']) ? $row['name'] : ""; ?>" required/>
                     
                     <label for="email">Email</label>
                     <input type="text" name="email" id="email" value="<?php echo isset($row['email']) ? $row['email'] : ""; ?>" required />
                     
                     <label for="comment">Password</label>
                     <input type="password" name="pass" id="pass" value="<?php echo isset($row['password']) ? $row['password'] : ""; ?>" required />

                     <input type="submit" name="Submit" id="btn" value="Submit" />
      
</form>
</body>
</html>