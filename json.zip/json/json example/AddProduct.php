<?php

	
	include_once '../Class/Category.php';
	include_once '../Class/Product.php';
	
		$objProduct = new Product();
		$objProduct->ProductID=isset($_REQUEST['ProductID']) ? $_REQUEST['ProductID'] : "";
		$objProduct->CategoryID=isset($_REQUEST['CategoryID']) ? $_REQUEST['CategoryID'] :"";
		$objProduct->ProductName=isset($_REQUEST['ProductName']) ? $_REQUEST['ProductName'] : "";
		$objProduct->ProductDescription=isset($_REQUEST['ProductDescription']) ? $_REQUEST['ProductName'] : "";
		$objProduct->Status=isset($_REQUEST['Status']) ?$_REQUEST['Status'] : "";
		$objProduct->ProductTitle=isset($_REQUEST['ProductTitle']) ? $_REQUEST['ProductTitle'] : "";
		$objProduct->IsActive=isset($_REQUEST['IsActive']) ? $_REQUEST['IsActive']: "";
		$objProduct->Height=isset($_REQUEST['Height']) ? $_REQUEST['Height'] : "";
		$objProduct->Weight=isset($_REQUEST['Weight']) ? $_REQUEST['Weight'] : "";
		$objProduct->Length=isset($_REQUEST['Length']) ? $_REQUEST['Length'] : "";
		$objProduct->Width=isset($_REQUEST['Width']) ? $_REQUEST['Width'] : "";
	
		if($objProduct->ProductID == "")
		{
			echo json_encode(array("success"=>false,"msg"=>"Please select Product id"));
			exit;
		}
		elseif($objProduct->CategoryID == "")
		{
			echo json_encode(array("success"=>false,"msg"=>"Please select Category id"));
			exit;
		}
		else if($objProduct->ProductName == "")
		{
		
			echo json_encode (array("success"=>false,"msg"=>"enter the Product Name "));
		
		}
		else if($objProduct->ProductDescription == "")
		{
		
			echo json_encode (array("success"=>false,"msg"=>"enter the Product Description "));
		
		}
		else if($objProduct->Status == "")
		{
		
			echo json_encode (array("success"=>false,"msg"=>"enter the Status "));
		
		}
		else if($objProduct->ProductTitle =="")
		{
		
			echo json_encode (array("success"=>false,"msg"=>"enter the Product Title"));
		
		}
		else if($objProduct->IsActive =="")
		{
		
			echo json_encode (array("success"=>false,"msg"=>"enter the IsActive  "));
		
		}
		else if($objProduct->Height == "")
		{
		
			echo json_encode (array("success"=>false,"msg"=>"Enter the Height "));
		
		}
		else if($objProduct->Weight == "")
		{
		
			echo json_encode (array("success"=>false,"msg"=>"Enter the Weight "));
		
		}
		else if($objProduct->Length =="")
		{
		
			echo json_encode (array("success"=>false,"msg"=>"Enter the Length "));
		
		}
		else if($objProduct->Width="")
		{
		
			echo json_encode (array("success"=>false,"msg"=>"Enter the Width "));
		
		}
	
		else
			{
				if($objProduct->Insert())
				{
					echo json_encode (array("success"=>true,"msg"=>"Insert succesfully"));
				}
				else
				{
					echo json_encode (array("success"=>false,"msg"=>"technical Error"));
				}
			}
	
	
	
	
	



?>