<?php
include_once 'DBConfig.php';
class Product extends DBConfig 
{
	public $ProductID;
	public $CategoryID;
	public $ProductName;
	public $ProductDescription;
	public $Status;
	public $ProductTitle;
	public $IsActive;
	public $Height;
	public $Weight;
	public $Length;
	public $Width;

public function __call($name,$arrguments)
{
	echo $name. 'Invalid Method Name ';

}

public function Insert()
{

		$InsertStr="insert into mst_product (
				CategoryID,
				ProductName,
				ProductDescription,
				Status,
				ProductTitle,
				Height,
				Weight,
				Length,
				Width)
		values( 
				'$this->CategoryID',
				'$this->ProductName',
				'$this->ProductDescription',
				'$this->Status',
				'$this->ProductTitle',
				'$this->Height',
				'$this->Weight',
				'$this->Length',
				'$this->Width'
			  )";
			  
			  if(mysqli_query($this->Conn,$InsertStr))
			  {
			  
			  	return true;
				
			  }
			  else
			  {
			  		return false;
			  }
	
	

}
public function SelectAll()
{
	$SelectStr="select 
			mst_product.ProductID,
			mst_product.CategoryID,
			mst_product.ProductName,
			mst_product.ProductDescription,
			mst_product.Status,
			mst_product.ProductTitle,
			mst_product.IsActive,
			mst_product.Height,
			mst_product.Weight,
			mst_product.Length,
			mst_product.Width
			
			from mst_product";
			if($SelectAllResult=mysqli_query($this->Conn,$SelectStr))
			{
				return $SelectAllResult;
			
			}
			else
			{
				return null;
			
			}
			
			

}
public function SelectByUser($ProductID)
{
	  $SelectStr="select
	
		ProductID,
		CategoryID,
		ProductName,
		ProductDescription,
		Status,
		ProductTitle,
		IsActive,
		Height,
		Weight,
		Length,
		Width
		
		from  mst_product where ProductID=$ProductID";
		
		if($SelectAllResult=mysqli_query($this->Conn,$SelectStr ))
		{
			return $SelectAllResult;
		
		}
		else
		{
			return null;
		
		}
}
public function Update($ProductID)
	{

		  $UpdateStr="update mst_product set
				
			CategoryID='$this->CategoryID',
			ProductName='$this->ProductName',
			ProductDescription='$this->ProductDescription',
			Status='$this->Status',
			ProductTitle='$this->ProductTitle',
			IsActive='$this->IsActive',
			Height='$this->Height',
			Weight='$this->Weight',
			Length='$this->Length',
			Width='$this->Width'
			
			 where ProductID='$this->ProductID'";
			if(mysqli_query($this->Conn,$UpdateStr))
			{
			
				return true;
				
			
			}
			else
			{
				return false;
			
			}
			
	

	}
public function Delete($ProductID)
	{
		  $DeleteStr="delete from mst_product where ProductID='$ProductID'";
		
		if(mysqli_query($this->Conn,$DeleteStr))
		{
		
			return true;
		
		}
		else
		{
			return false;
		
		}
		
	}
		
		
}



?>