<?php
	include_once 'SessionCheck.php';
	include_once '../Class/Category.php';
	include_once '../Class/Product.php';
	$objProduct = new Product();
	$objCategory = new Category();
	$page = "Product";
	$pageadd = "Product";
	$ErrorMsg="";
	$SuccessMsg="";
	if(isset($_POST['btnSave']))
	{
		
		$objProduct->ProductID=trim($_POST['ProductID']);
		$objProduct->CategoryID=trim($_POST['CategoryID']);
		$objProduct->ProductName=trim($_POST['ProductName']);
		$objProduct->ProductDescription=trim($_POST['ProductDescription']);
		$objProduct->Status=trim($_POST['Status']);
		$objProduct->ProductTitle=trim($_POST['ProductTitle']);
		$objProduct->IsActive=$_POST['Active'];
		$objProduct->Height=trim($_POST['Height']);
		$objProduct->Weight=trim($_POST['Weight']);
		$objProduct->Length=trim($_POST['Length']);
		$objProduct->Width=trim($_POST['Width']);
		
		if(empty($objProduct->ProductName))
		{
			$ErrorMsg="Enter Product Name";
		}
		else if(empty($objProduct->ProductDescription))
		{
			$ErrorMsg="Enter Product Description";
		}
		else if(empty($objProduct->Status))
		{
			$ErrorMsg="Enter Product Status";
		}
		
		else if(empty($objProduct->ProductTitle))
		{
			$ErrorMsg="Enter Product Title";
		}
		
		else if(empty($objProduct->Height))
		{
			$ErrorMsg="Enter Product Height";
		}
		
		else if(empty($objProduct->Weight))
		{
			$ErrorMsg="Enter Product Weight";
		}
		
		else if(empty($objProduct->Length))
		{
			$ErrorMsg="Enter Product Length";
		}
		
		else if(empty($objProduct->Width))
		{
			$ErrorMsg="Enter Product Width";
		}
		
		
		if(empty($ErrorMsg))
		{
			if(isset($objProduct->ProductID) and !empty($objProduct->ProductID))
			{
				if($objProduct->Update())
				{
					header('Location:ProductList.php');
				}
				else
				{
					$ErrorMsg="Error in Update Operation:".mysql_error();
				}
			}
			else
			{
				if($objProduct->Insert())
				{
					$SuccessMsg="Inserted Successfully";
				}
				else
				{
					$ErrorMsg="Error in Insert Operation:".mysql_error();
				}
			}
		}
	}
?>
<?php
	if(isset($_GET['mode']))
	{
		$mode=strval(trim($_GET['mode']));
		if($mode=='Edit')
		{
			if($objResult=$objProduct->SelectByUser($_GET['ProductID']))
			{
			
				if(isset($objResult) and $objResult!=null)
				{
					$objRow=mysqli_fetch_assoc($objResult);
				}
			}
			else
			{
				$ErrorMsg="Error In Edit Operation.";
			}
		}
	}
	?>	
	


<!DOCTYPE html>
<!--[if IE 8]> 
<html lang="en" class="ie8 no-js">
<![endif]-->
<!--[if IE 9]> 
<html lang="en" class="ie9 no-js">
<![endif]-->
<!--[if !IE]><!--> 
<html lang="en" class="no-js">
	<!--<![endif]-->
	<!-- BEGIN HEAD -->
	<head>
		<meta charset="utf-8" />
		<title>gks-Product</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta content="width=device-width, initial-scale=1.0" name="viewport" />
		<meta content="" name="description" />
		<meta content="" name="author" />
		<meta name="MobileOptimized" content="320">
		<!-- BEGIN GLOBAL MANDATORY STYLES -->          
		<link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
		<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
		<link href="assets/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
		<!-- END GLOBAL MANDATORY STYLES -->
		<!-- BEGIN PAGE LEVEL STYLES -->
		<link rel="stylesheet" type="text/css" href="assets/plugins/bootstrap-fileupload/bootstrap-fileupload.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/gritter/css/jquery.gritter.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/select2/select2_metro.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/clockface/css/clockface.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/bootstrap-datepicker/css/datepicker.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/bootstrap-timepicker/compiled/timepicker.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/bootstrap-colorpicker/css/colorpicker.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/bootstrap-daterangepicker/daterangepicker-bs3.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/bootstrap-datetimepicker/css/datetimepicker.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/jquery-multi-select/css/multi-select.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/bootstrap-switch/static/stylesheets/bootstrap-switch-metro.css"/>
		<link rel="stylesheet" type="text/css" href="assets/plugins/jquery-tags-input/jquery.tagsinput.css" />
		<link rel="stylesheet" type="text/css" href="assets/plugins/bootstrap-markdown/css/bootstrap-markdown.min.css">
		<!-- END PAGE LEVEL STYLES -->
		<!-- BEGIN THEME STYLES --> 
		<link href="assets/css/style-metronic.css" rel="stylesheet" type="text/css"/>
		<link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
		<link href="assets/css/style-responsive.css" rel="stylesheet" type="text/css"/>
		<link href="assets/css/plugins.css" rel="stylesheet" type="text/css"/>
		<link href="assets/css/themes/default.css" rel="stylesheet" type="text/css" id="style_color"/>
		<link href="assets/css/custom.css" rel="stylesheet" type="text/css"/>
		<!-- END THEME STYLES -->
		<link rel="shortcut icon" href="favicon.ico" />
	</head>
	<!-- END HEAD -->
	<!-- BEGIN BODY -->
	<body class="page-header-fixed">
		<!-- BEGIN HEADER -->   
		<?php
			include_once 'Division/Header.php';
			?>
		<!-- END HEADER -->
		<div class="clearfix"></div>
		<!-- BEGIN CONTAINER -->
		<div class="page-container">
			<!-- BEGIN SIDEBAR -->
			<div class="page-sidebar navbar-collapse collapse">
				<!-- BEGIN SIDEBAR MENU -->        
				<?php
					include_once 'Division/SideMenu.php';
					?>      
				<!-- END SIDEBAR MENU -->
			</div>
			<!-- END SIDEBAR -->
			<!-- BEGIN PAGE -->  
			<div class="page-content">
				<!-- BEGIN PAGE HEADER-->   
				<div class="row">
					<div class="col-md-12">
						<!-- BEGIN PAGE TITLE & BREADCRUMB-->
						<h3 class="page-title">
							Product
						</h3>
						<ul class="page-breadcrumb breadcrumb">
							<li>
								<i class="icon-home"></i>
								<a href="home.php">Home</a> 
								<i class="icon-angle-right"></i>
							</li>
							<li><a href="AlbumList.php">Product</a></li>
							<li class="pull-right">
								<div id="dashboard-report-range" class="dashboard-date-range tooltips" data-placement="top" data-original-title="Change dashboard date range">
									<i class="icon-calendar"></i>
									<span></span>
									<i class="icon-angle-down"></i>
								</div>
							</li>
						</ul>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
				<!-- END PAGE HEADER-->
				<!-- BEGIN PAGE CONTENT-->
				<?php
					if(isset($ErrorMsg) and !empty($ErrorMsg))
					{
					?>
				<div class="alert alert-danger">
					<strong>Error!</strong> <?php echo $ErrorMsg; ?>
				</div>
				<?php
					}
					?>
				<?php
					if(isset($SuccessMsg) and !empty($SuccessMsg))
					{
					?>
				<div class="alert alert-success">
					<strong>Success!</strong> <?php echo $SuccessMsg; ?>
				</div>
				<?php
					}
					?>
				<div class="row">
					<div class="col-md-10 ">
						<!-- BEGIN SAMPLE FORM PORTLET-->   
						<div class="portlet box green ">
							<div class="portlet-title">
								<div class="caption">
									<i class="icon-reorder"></i> <?php if(isset($mode)) echo $mode; else echo "Add";?> Product
								</div>
							</div>
							<div class="portlet-body form">
								<form class="form-horizontal" id="form_sample" role="form" method="post" enctype="multipart/form-data">
									<div class="form-body">
										<input type='hidden' name='ProductID' value='<?php if(isset($objRow['ProductID'])) echo $objRow['ProductID']; ?>'>
										<input type='hidden' name='Active' value='<?php if(isset($objRow['IsActive'])) echo $objRow['IsActive']; ?>'>
                                        
										<div class="form-group">
                                        <label  class="col-md-3 control-label">Category Name <span class="required" aria-required="true">* </span></label>
											<div class="col-md-9">
                                            <select  class="form-control input-large select2me" data-placeholder="Select..." name='CategoryID' id='CategoryID'>
												<option selected  value=""></option>
												<?php
													$objResultCat=$objCategory->SelectAll();
													if(isset($objResultCat) and $objResultCat!=null)
													{
														if(mysqli_num_rows($objResultCat)>0)
														{
										while($objRowCat=mysqli_fetch_assoc($objResultCat))
															{
																if(isset($objRow['CategoryID']) and $objRow['CategoryID']==$objRowCat['CategoryID'])
																{
																	echo "<option selected value='".$objRowCat['CategoryID']."'>".$objRowCat['CategoryName']."</option>";
																}
																else
																{
																	echo "<option value='".$objRowCat['CategoryID']."'>".$objRowCat['CategoryName']."</option>";
																}
															}
														}
													}
													?>
												</select>
												
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label  class="col-md-3 control-label">Product Name <span class="required" aria-required="true">* </span></label>
											<div class="col-md-9">
                                        <input type="text" class="form-control"  value='<?php if(isset($objRow['ProductName'])) echo $objRow['ProductName']; ?>' name='ProductName' id='ProductName' placeholder="Enter Product Name">
                                        	</div>
                                        </div>
                                        
                                        <div class="form-group">
											<label  class="col-md-3 control-label">Product Description <span class="required" aria-required="true">* </span></label>
											<div class="col-md-9">
                                        <textarea class="form-control" rows="3" name='ProductDescription' id='ProductDescription'>
												<?php if(isset($objRow['ProductDescription'])) echo $objRow['ProductDescription']; ?>
												</textarea>
                                        	</div>
                                        </div>
                                        
                                        <div class="form-group">
											<label  class="col-md-3 control-label">Product Status <span class="required" aria-required="true">* </span></label>
											<div class="col-md-9">
                                        <input type="text" class="form-control"  value='<?php if(isset($objRow['Status'])) echo $objRow['Status']; ?>' name='Status' id='Status' placeholder="Enter Product Status">
                                        	</div>
                                        </div>
                                        
                                        <div class="form-group">
											<label  class="col-md-3 control-label">Product Title <span class="required" aria-required="true">* </span></label>
											<div class="col-md-9">
                                        <input type="text" class="form-control"  value='<?php if(isset($objRow['ProductTitle'])) echo $objRow['ProductTitle']; ?>' name='ProductTitle' id='ProductTitle' placeholder="Enter Product Title">
                                        	</div>
                                        </div>
                                        
                                        
                                        <div class="form-group">
											<label  class="col-md-3 control-label"> Height <span class="required" aria-required="true">* </span></label>
											<div class="col-md-9">
												<input type="text" class="form-control"  value='<?php if(isset($objRow['Height'])) echo $objRow['Height']; ?>' name='Height' id='Height' placeholder="Enter Product Height">
											</div>
										</div>
                                        
                                        
                                        <div class="form-group">
											<label  class="col-md-3 control-label">Weight<span class="required" aria-required="true">* </span></label>
											<div class="col-md-9">
												<input type="text" class="form-control"  value='<?php if(isset($objRow['Weight'])) echo $objRow['Weight']; ?>' name='Weight' id='Weight' placeholder="Enter Product Weight">
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label  class="col-md-3 control-label">Length<span class="required" aria-required="true">* </span></label>
											<div class="col-md-9">
												<input type="text" class="form-control"  value='<?php if(isset($objRow['Length'])) echo $objRow['Length']; ?>' name='Length' id='Length' placeholder="Enter Product Length">
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label  class="col-md-3 control-label">Width<span class="required" aria-required="true">* </span></label>
											<div class="col-md-9">
												<input type="text" class="form-control"  value='<?php if(isset($objRow['Width'])) echo $objRow['Width']; ?>' name='Width' id='Width' placeholder="Enter Product Width">
											</div>
										</div>
                                        
										
									</div>
									<div class="form-actions fluid">
										<div class="col-md-offset-3 col-md-9">
											<button type="submit" class="btn green" name='btnSave' id='btnSave'><i class="icon-ok"></i> Save</button>
											<button type="button" class="btn default">Cancel</button>                                  
										</div>
									</div>
								</form>
							</div>
						</div>
						<!-- END SAMPLE FORM PORTLET-->
					</div>
				</div>
				<!-- END PAGE CONTENT-->    
			</div>
			<!-- END PAGE -->  
		</div>
		<!-- END CONTAINER -->
		<!-- BEGIN FOOTER -->
		<?php
			include_once 'Division/Footer.php';
		?>
		<!-- END PAGE LEVEL SCRIPTS -->