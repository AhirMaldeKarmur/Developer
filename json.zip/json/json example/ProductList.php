<?php 
	include_once 'SessionCheck.php'; 
	include_once '../Class/Product.php';
	include_once '../Class/Category.php';
	$objProduct=new Product();
	$objCategory=new Category();
	$page = "Product";
	$pageadd = "";
	$ErrorMsg="";
	$SuccessMsg="";
	if(isset($_GET['mode']))
	{
		$mode=strval(trim($_GET['mode']));
		if($mode=='Delete')
		{
			if($objProduct->Delete($_GET['ProductID']))
			{
				$SuccessMsg="Deleted Successfully.";
			}
			else
			{
				$ErrorMsg="Error In Delete Operation.";
			}
		}
		if($mode=='IsActive')
		{
			if($objProduct->SelectIsActiveByUser($_GET['ProductID']))
			{
				$SuccessMsg="IsActive Updated Successfully.";
			}
			else
			{
				$ErrorMsg="Error In IsActive Update Operation.";
			}
		}
	}
?>
<!DOCTYPE html>
<!--[if IE 8]> 
<html lang="en" class="ie8 no-js">
<![endif]-->
<!--[if IE 9]> 
<html lang="en" class="ie9 no-js">
<![endif]-->
<!--[if !IE]><!--> 
<html lang="en" class="no-js">
	<!--<![endif]-->
	<!-- BEGIN HEAD -->
	<head>
		<meta charset="utf-8" />
		<title>gks-Product</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta content="width=device-width, initial-scale=1.0" name="viewport" />
		<meta content="" name="description" />
		<meta content="" name="author" />
		<meta name="MobileOptimized" content="320">
		<!-- BEGIN GLOBAL MANDATORY STYLES -->          
		<link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
		<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
		<link href="assets/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
		<!-- END GLOBAL MANDATORY STYLES -->
		<!-- BEGIN PAGE LEVEL STYLES -->
		<link rel="stylesheet" type="text/css" href="assets/plugins/select2/select2_metro.css" />
		<link rel="stylesheet" href="assets/plugins/data-tables/DT_bootstrap.css" />
		<!-- END PAGE LEVEL STYLES -->
		<!-- BEGIN THEME STYLES --> 
		<link href="assets/css/style-metronic.css" rel="stylesheet" type="text/css"/>
		<link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
		<link href="assets/css/style-responsive.css" rel="stylesheet" type="text/css"/>
		<link href="assets/css/plugins.css" rel="stylesheet" type="text/css"/>
		<link href="assets/css/themes/default.css" rel="stylesheet" type="text/css" id="style_color"/>
		<link href="assets/css/custom.css" rel="stylesheet" type="text/css"/>
		<!-- END THEME STYLES -->
		<link rel="shortcut icon" href="favicon.ico" />
	</head>
	<!-- END HEAD -->
	<!-- BEGIN BODY -->
	<body class="page-header-fixed">
		<!-- BEGIN HEADER -->   
		<?php
			include_once 'Division/Header.php';
			?>  
		<!-- END HEADER -->
		<div class="clearfix"></div>
		<!-- BEGIN CONTAINER -->
		<div class="page-container">
			<!-- BEGIN SIDEBAR -->
			<div class="page-sidebar navbar-collapse collapse">
				<!-- BEGIN SIDEBAR MENU -->        
				<?php
					include_once 'Division/SideMenu.php';
					?>
				<!-- END SIDEBAR MENU -->
			</div>
			<!-- END SIDEBAR -->
			<!-- BEGIN PAGE -->
			<div class="page-content">
				<!-- BEGIN PAGE HEADER-->
				<div class="row">
					<div class="col-md-12">
						<!-- BEGIN PAGE TITLE & BREADCRUMB-->
						<h3 class="page-title">
							Product
						</h3>
						<ul class="page-breadcrumb breadcrumb">
							<li>
								<i class="icon-home"></i>
								<a href="home.php">Home</a> 
								<i class="icon-angle-right"></i>
							</li>
							<li>Product</li>
							<li class="pull-right">
								<div id="dashboard-report-range" class="dashboard-date-range tooltips" data-placement="top" data-original-title="Change dashboard date range">
									<i class="icon-calendar"></i>
									<span></span>
									<i class="icon-angle-down"></i>
								</div>
							</li>
						</ul>
						<!-- END PAGE TITLE & BREADCRUMB-->
					</div>
				</div>
				<!-- END PAGE HEADER-->
				<!-- BEGIN PAGE CONTENT-->
				<?php
					if(isset($ErrorMsg) and !empty($ErrorMsg))
					{
					?>
				<div class="alert alert-danger">
					<strong>Error!</strong> <?php echo $ErrorMsg; ?>
				</div>
				<?php
					}
					?>
				<?php
					if(isset($SuccessMsg) and !empty($SuccessMsg))
					{
					?>
				<div class="alert alert-success">
					<strong>Success!</strong> <?php echo $SuccessMsg; ?>
				</div>
				<?php
					}
					?>
				<div class="row">
					<div class="col-md-12 col-sm-12">
						<!-- BEGIN EXAMPLE TABLE PORTLET-->
						<div class="portlet box grey">
							<div class="portlet-title">
								<div class="caption"><i class="icon-user"></i>Product List</div>
								<div class="actions">
									<a href="ProductAddEdit.php" class="btn blue"><i class="icon-pencil"></i> Add</a>
									<!--div class="btn-group">
										<a class="btn green" href="#" data-toggle="dropdown">
										<i class="icon-cogs"></i> Tools
										<i class="icon-angle-down"></i>
										</a>
										<!ul class="dropdown-menu pull-right">
										   <li><a href="#"><i class="icon-pencil"></i> Edit</a></li>
										   <li><a href="#"><i class="icon-trash"></i> Delete</a></li>
										   <li><a href="#"><i class="icon-ban-circle"></i> Ban</a></li>
										   <li class="divider"></li>
										   <li><a href="#"><i class="i"></i> Make admin</a></li>
										</ul>
										</div-->
								</div>
							</div>
							<div class="portlet-body">
								<table class="table table-striped table-bordered table-hover dataTable" id="sample_2" aria-describedby="sample_2_info">
									<thead>
										<tr role="row">
											<th style="width: 34px;" class="sorting_disabled" role="columnheader" rowspan="1" colspan="1" aria-label="">
												<div class="checker"><span>
													<input type="checkbox" class="group-checkable" data-set="#sample_2 .checkboxes"></span>
												</div>
											</th>
											<th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" aria-label="ProductName">ProductName</th>
											
                                            <th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" aria-label="ProductDescription">ProductDescription</th>
                                            <th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" aria-label="Status">Status</th>
                                            <th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" aria-label="ProductTitle">ProductTitle</th>
                                            
                                            <th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" aria-label="Height">Height</th>
                                            
                                            <th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" aria-label="Weight">Weight</th>
                                            
                                            <th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" aria-label="Length">Length</th>
                                            
                                            <th class="sorting" role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" aria-label="WidthWidth">Width</th>
                                            
											<th role="columnheader" tabindex="0" aria-controls="sample_2" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 98px;">Action</th>
										</tr>
									</thead>
									<tbody role="alert" aria-live="polite" aria-relevant="all">
										<?php
											$objResult=$objProduct->SelectAll();
											if(isset($objResult) and $objResult!=null)
											{
											if(mysqli_num_rows($objResult)>0)
												{
													$RowCounter=0;
														while($objRowCat=mysqli_fetch_assoc($objResult))
													{
														$RowCounter++;
														if($RowCounter%2==0)
														{
															echo "<tr class='gradeX odd'>";
														}
														else
														{
															echo "<tr class='gradeX even'>";
														}
								echo "<td class=' sorting_1'><div class='checker'><span><input type='checkbox' class='checkboxes' value=".$objRowCat['ProductID']." /></span></div></td>";
								echo "<td class=' '>".$objRowCat['ProductName']."</td>";
								echo "<td class=' '>".$objRowCat['ProductDescription']."</td>";
								echo "<td class=' '>".$objRowCat['Status']."</td>";
								echo "<td class=' '>".$objRowCat['ProductTitle']."</td>";
								echo "<td class=' '>".$objRowCat['Height']."</td>";
								echo "<td class=' '>".$objRowCat['Weight']."</td>";
								echo "<td class=' '>".$objRowCat['Length']."</td>";
								echo "<td class=' '>".$objRowCat['Width']."</td>";
								echo "<td><a href='ProductAddEdit.php?mode=Edit&ProductID=".$objRowCat['ProductID']."' class='btn default btn-xs purple'><i class='icon-edit'></i></a>&nbsp;&nbsp;";
														echo "<a href='ProductList.php?mode=Delete&ProductID=".$objRowCat['ProductID']."' class='btn default btn-xs black' onClick=\"return confirm('Are You sure want to Delete?')\"><i class='icon-trash'></i> </a></td>";
														echo "</tr>";
													}
												}
											}
											?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
				<!-- END EXAMPLE TABLE PORTLET-->
			</div>
		</div>
		<!-- END PAGE CONTENT-->
		</div>
		<!-- END PAGE -->
		</div>
		<!-- END CONTAINER -->
		<!-- BEGIN FOOTER -->
		<?php
			include_once 'Division/Footer.php';
		?>
		<!-- END FOOTER -->
	</body>
	<!-- END BODY -->
</html>