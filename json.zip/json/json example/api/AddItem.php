<?php


include_once'../class/Item.php';
include_once'../class/Product.php';
include_once'../class/Category.php';

$objItem = new Item();
$objProduct = new Product();
$objCategory = new Category();

	$objItem->ItemID=isset($_REQUEST[['ItemID']) ? $_REQUEST['ItemID'] : "" ;
	$objItem->ProductID=isset($_REQUEST['ProductID']) ? $_REQUEST['ProductID'] : "";
	$objItem->CategoryID=isset($_REQUEST['CategoryID']) ? $_REQUEST['CategoryID'] :"";
	$objItem->ItemName=isset($_REQUEST['ItemName']) ? $_REQUEST['ItemName'] : "";
	$objItem->Color=isset($_REQUEST['Color']) ? $_REQUEST['Color'] : "";
	$objItem->Size=isset($_REQUEST['Size']) ? $_REQUEST['Size'] : "";
	$objItem->Width=isset($_REQUEST['Width']) ? $_REQUEST['Width'] : ""; 
	$objItem->Height=isset($_REQUEST['Height']) ? $_REQUEST['Height'] : "";
	$objItem->Length=isset($_REQUEST['Length']) ?  $_REQUEST['Length'] : "";
	$objItem->weight=isset($_REQUEST['weight']) ?  $_REQUEST['weight'] : ""; 
	$objItem->Qty=isset($_REQUEST['Qty']) ? $_REQUEST['Qty'] : "";
	
	if($objItem->ItemName ="")
	{
	
		echo json_encode (array("sucess"=>false,"msg"=>"Enter the Item Name"));
	
	}
	else if(empty($objItem->Color))
	{
		echo json_encode (array("sucess"=>false,"msg"=>"Enter the Item Name"));
	
	}
	
	else if(empty($objItem->Size))
	{
		echo json_encode (array("sucess"=>false,"msg"=>"Enter the Item Name"));
	
	}
	else if(empty($objItem->Width))
	{
		echo json_encode (array("sucess"=>false,"msg"=>"Enter the Item Name"));
	
	}
	else if(empty($objItem->Height))
	{
	
		echo json_encode (array("sucess"=>false,"msg"=>"Enter the Item Name"));
		
	}
	else if(empty($objItem->Length))
	{
	
		echo json_encode (array("sucess"=>false,"msg"=>"Enter the Item Name"));
	
	}
	else if(empty($objItem->weight))
	{
	
		echo json_encode (array("sucess"=>false,"msg"=>"Enter the Item Name"));
		
	}
	else if(empty($objItem->Qty))
	{
	
		echo json_encode (array("sucess"=>false,"msg"=>"Enter the Item Name"));
	}
	
	
	if(isset($_FILES['txtImagePath']['name']) && !empty($_FILES['txtImagePath']['name']))
		{
			$info = explode(".",$_FILES['txtImagePath']['name']);
			$ext = end($info); // get the extension of the file
			$filename = "Item-".time().'.'.$ext;
			
			if(empty($_FILES['txtImagePath']['name']))
			{
				$ErrorMsg.="<br/>Upload Only Image File.";
			}
			else if(!move_uploaded_file($_FILES['txtImagePath']['tmp_name'],'Upload/Item/Large/'.$filename))	{
				$ErrorMsg.="<br/>Something wrong in uploading File";
			}
			else
			{	
				
					
				if(isset($_GET['mode']) && $_GET['mode'] == "Edit")
				{
				
					if(file_exists("Upload/Item/Large/".$_POST['ItemImagePath']))
					{
						
						unlink('Upload/Item/Large/'.$_POST['ItemImagePath']);
					}
				}
			
			
			$objItem->ImagePath=mysqli_real_escape_string($objItem->Conn,trim($filename));
			}
		}
		else
		{
			
			$objItem->ImagePath=mysqli_real_escape_string($objItem->Conn,trim($_POST['ItemImagePath']));
		}
		



?>