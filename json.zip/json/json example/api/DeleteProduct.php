<?php

include '../class/Product.php';

$objProduct = new Product();

$objProduct->ProductID = isset($_REQUEST['ProductID']) ? $_REQUEST['ProductID'] : '';
	
	if($objProduct->ProductID == ""){
		echo json_encode(array("success"=>false,"msg"=>"Please select Product id"));
		
	}

if($objProduct = $objProduct->Delete($objProduct->ProductID))
	{
		echo json_encode(array("success"=>true,"msg"=>"Romeve successfully"));
		exit;
	}
	else
	{
		echo json_encode(array("success"=>false,"msg"=>"Technical Error"));
		exit;
	}


?>