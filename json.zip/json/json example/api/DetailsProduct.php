<?php

	include_once '../Class/Category.php';
	include_once '../Class/Product.php';
	
	$objProduct = new Product();
	
	$objProduct->ProductID=isset($_REQUEST['ProductID']) ? $_REQUEST['ProductID'] : '';
	

	if($objProduct->ProductID =="")
	{
		
		echo json_encode (array("success"=>false,"msg"=>"please select Product Id"));
		
			
	}
		
		
		$objResult=$objProduct->SelectByUser($objProduct->ProductID);
		
		if(isset($objResult) and $objResult!=null)
			{	
				
				if(mysqli_num_rows($objResult)>0)
				{
					$objRowCat=mysqli_fetch_assoc($objResult);
					
					
					$ProductID=isset($objRowCat['ProductID']) ? $objRowCat['ProductID'] : ""; 
					$CategoryID=isset($objRowCat['CategoryID']) ? $objRowCat['CategoryID'] : ""; 
					$ProductName=isset($objRowCat['ProductName']) ? $objRowCat['ProductName'] : "";
					$ProductDescription=isset($objRowCat['ProductDescription']) ? $objRowCat['ProductDescription'] : ""  ;
					$Status=isset($objRowCat['Status']) ? $objRowCat['Status'] : "";
					$ProductTitle=isset($objRowCat['ProductTitle']) ? $objRowCat['ProductTitle'] : "";
					$IsActive=isset($objRowCat['IsActive']) ? $objRowCat['IsActive'] : "";
					$Height=isset($objRowCat['Height']) ? $objRowCat['Height'] : "";
					$Weight=isset($objRowCat['Weight']) ? $objRowCat['Weight'] : "";
					$Length=isset($objRowCat['Length']) ? $objRowCat['Length'] : "";
					$Width=isset($objRowCat['Width']) ? $objRowCat['Width'] : "";
					
					$json []=array(
					
						'ProductID'=>$ProductID,
						'CategoryID'=>$CategoryID,
						'ProductName'=>$ProductName,
						'ProductDescription'=>$ProductDescription,
						'Status'=>$Status,
						'ProductTitle'=>$ProductTitle,
						'IsActive'=>$IsActive,
						'Height'=>$Height,
						'Weight'=>$Weight,
						'Length'=>$Length,
						'Width'=>$Width
					
						);
						
				
					echo json_encode (array("success"=>true,"msg"=>$json));
				}		
				else
				{
			
					echo json_encode (array("success"=>false,"msg"=>"No Product Found "));		
					
				}
			}
			
			else
			{
			
				echo json_encode (array("sucess"=>false,"msg"=>"Technical Error"));
			
			}
						
				
			
	
?>
